import UIKit

enum CompassPoint {
    case bread
    case mayo
    case meat
    case cheese
    case letace
    case bread
}
